package pgn.examenMarzo.marcasYProductos;

public class PrecioNotValidException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PrecioNotValidException(String message) {
		super(message);
	}
}
